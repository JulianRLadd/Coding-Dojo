from django.apps import AppConfig


class FavAppConfig(AppConfig):
    name = 'fav_app'
