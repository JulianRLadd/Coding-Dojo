from django.apps import AppConfig


class GoldNinjaAppConfig(AppConfig):
    name = 'gold_ninja_app'
