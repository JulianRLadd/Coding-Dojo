class UsersController < ApplicationController
  def create
    @user = User.create(user_params)
    if @user.valid?
        flash[:success] = "You did it! The form was submitted!"
        redirect_to new_session_path
    else
        redirect_to new_user_path, notice: @user.errors.full_messages
    end
  end

  def new
    render "new"
  end

  def show
    @user = User.find(session[:user_id])
    render "show"
  end

  def edit
    render "edit"
  end
  private 
    def user_params
        params.require(:user).permit(:name, :email, :password, :password_confirmation)#.merge(user: User.find(session[:user_id]))
    end

end