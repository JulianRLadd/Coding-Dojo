class UsersController < ApplicationController
  def create
    @user = User.create(user_params)
    if user.valid?
      flash[:success] = "You did it! The form was submitted!"
      redirect_to "/user/:id"
    else
      redirect_to "/users/new", alert: user.errors.full_messages
    end
  end

  def show
  end

  def edit
  end
  private 
    def user_params
      params.require(:user).permit(:name, :email, :password, :password_confirmation)
    end
end
