class UsersController < ApplicationController
  def create
    @user = User.create(user_params)
    if @user.valid?
        flash[:notice] = "You did it! The form was submitted!"
        redirect_to new_session_path
    else
        redirect_to new_user_path, notice: @user.errors.full_messages
    end
  end

  def new
    render "new"
  end

  def update
    @user = User.find(session[:user_id])
    @user.update(user_params)
    unless @user.errors.full_messages
      flash[:notice] = "You did it! The form was submitted!"
      redirect_to user_path
    else
      redirect_to edit_user_path(session[:user_id]), notice: @user.errors.full_messages
    end
  end
  def show
    @user = User.find(session[:user_id])
    render "show"
  end

  def edit
    @user = User.find(session[:user_id])
    render "edit"
  end
  def destroy
    @user = User.find(session[:user_id])
    @user.destroy
    session[:user_id]= nil
    redirect_to '/users/new'
end
  private 
    def user_params
        params.require(:user).permit(:name, :email, :password, :password_confirmation)#.merge(user: User.find(session[:user_id]))
    end
end