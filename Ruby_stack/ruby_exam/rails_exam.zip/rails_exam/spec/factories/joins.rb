FactoryBot.define do
  factory :join do
    user { nil }
    group { nil }
  end
end
