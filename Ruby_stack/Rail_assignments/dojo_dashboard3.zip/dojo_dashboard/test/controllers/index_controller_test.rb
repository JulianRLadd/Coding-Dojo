require 'test_helper'

class IndexControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
