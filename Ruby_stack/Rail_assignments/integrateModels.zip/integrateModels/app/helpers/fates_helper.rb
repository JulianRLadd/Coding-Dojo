module FatesHelper
end
