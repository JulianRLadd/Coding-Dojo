class Survey < ActiveRecord::Base
end
