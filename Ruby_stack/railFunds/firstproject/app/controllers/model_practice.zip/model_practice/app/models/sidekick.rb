class Sidekick < ActiveRecord::Base
  belongs_to :hero
end
