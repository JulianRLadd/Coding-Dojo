module HerosHelper
end
