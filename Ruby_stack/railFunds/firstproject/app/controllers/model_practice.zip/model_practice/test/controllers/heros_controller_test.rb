require 'test_helper'

class HerosControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
