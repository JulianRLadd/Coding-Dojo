array = [9,18,3,7,6]
arr = %w{Matz Guido Choi Ladd John}

puts array
puts arr.at(3)
puts array.reverse
puts arr.values_at(1,3)
puts arr.delete(1)
puts array.length
puts array.sort
puts arr.slice(3)
puts arr.shuffle()
puts arr.join(' + ')
puts array.insert(4,99)

