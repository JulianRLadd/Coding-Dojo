array = [34,76,1,65,21,9,18,3,7,6]

puts array.include?(22)
puts array.last
puts array.max
puts array.min

