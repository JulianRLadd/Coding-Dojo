from django.apps import AppConfig


class OrgAppConfig(AppConfig):
    name = 'org_app'
