function displayName(data) {
    console.log(data);
}   
function stuff(){
$.get("https://api.github.com/users/SoraVladd", displayName)
}