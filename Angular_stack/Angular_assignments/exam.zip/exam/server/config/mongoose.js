	mongoose = require('mongoose')
	module.exports = mongoose.connect('mongodb://localhost/exam_db', {useNewUrlParser: true});
